import webbrowser
class Movie():
    """
    This class creates data structure to store information of favorite movies.
    Information includes Movie Title, Stotyline, poster URL and Youtube link of movie trailer
    """

    def __init__(self, title, movie_storyline, poster_image_url, trailer_youtube_url):
        self.title = title
        self.movie_storyline = movie_storyline
        self.poster_image_url = poster_image_url
        self.trailer_youtube_url = trailer_youtube_url
        
    def show_trailer(self):
        webbrowser.open(self.trailer_youtube_url)
        
